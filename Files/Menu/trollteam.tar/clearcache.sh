#!/bin/bash
# Script by : _joekers_
echo "echo 3 > /proc/sys/vm/drop_caches"
clear
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]"
echo -e "\e[0m                                                   "
echo -e "\e[93m           AutoScriptVPS by  _joekers_            "
echo -e "\e[0m                                                   "
echo -e "\e[93m                  Cache  Cleared                  "
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]\e[0m"
