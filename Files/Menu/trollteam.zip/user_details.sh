#!/bin/bash
# Script by : _joekers_
clear
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]"
echo -e "\e[0m                                                   "
echo -e "\e[93m           AutoScriptVPS by  _joekers_            "
echo -e "\e[0m                                                   "
read -p "         Username       : " User
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]\e[0m"
sleep 1
user_details_lib $User