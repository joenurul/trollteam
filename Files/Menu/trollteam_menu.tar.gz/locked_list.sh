#!/bin/bash
# Script by : _joekers_
if [ -f "$FILE" ];
then
cd
nano /etc/Locked_List.txt
else
cd
nano /etc/Locked_List.txt
fi